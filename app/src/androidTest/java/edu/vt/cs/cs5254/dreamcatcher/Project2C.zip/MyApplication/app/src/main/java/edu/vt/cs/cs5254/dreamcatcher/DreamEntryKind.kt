package edu.vt.cs.cs5254.dreamcatcher

enum class DreamEntryKind {
    CONCEIVED, DEFERRED, FULFILLED, REFLECTION
}